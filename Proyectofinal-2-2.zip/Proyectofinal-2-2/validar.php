<?php
include('conexion.php');

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$consulta = "SELECT * FROM administrador where usuario = '$usuario' and password = '$password' ";
$resultado = mysqli_query(conectar(),$consulta);
echo $consulta;

$filas = mysqli_num_rows($resultado);

if ($filas) {
    header("location:on_admin.html");
} else {
    include("admin.html");
?>
    <div class="alert alert-danger">ERROR</div>
<?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);


?>